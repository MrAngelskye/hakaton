НарядAI: СИНТЕТИЧЕСКИЙ учебный набор, кейс №1.
Все люди, наряды, события, инвентарные объекты и нормы вымышлены.
Паролей и настоящих фотографий ремонта здесь нет. Модель не обучена.

dataset.json — связанные исходные записи и отдельные ключи ответов.
exports/ai_training.sqlite3 — готовая отдельная SQLite для просмотра.
exports/postgresql.sql — импорт в отдельную схему naryadai_ai_training.
exports/csv — таблицы; exports/train.jsonl, validation.jsonl, test.jsonl — примеры для ИИ.
exports/rag — история оборудования без ответов; соблюдайте разделение и available_at.
answer_keys служат только учебными ответами, не входом модели.
Изображения отсутствуют: photo_evidence содержит только имитацию метаданных.
Не импортируйте эту схему в рабочие таблицы приложения.

Код, инструкции и ограничения:
https://github.com/MrAngelskye/hakaton/tree/codex/ai-training-dataset/database/ai_training
